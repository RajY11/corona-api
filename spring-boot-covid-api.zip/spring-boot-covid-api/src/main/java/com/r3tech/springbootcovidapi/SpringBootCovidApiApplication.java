package com.r3tech.springbootcovidapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCovidApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCovidApiApplication.class, args);
	}

}
